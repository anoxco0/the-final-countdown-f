
export const LOGIN_LOADING = "LOGIN_LOADING";
export const LOGIN_SUCCESS = "LOGIN_SUCCESS";
export const LOGIN_FAILURE = "LOGIN_FAILURE";

export const loginLoading=()=>({
    type:LOGIN_LOADING,
});

export const loginSuccess = (payload)=>({
    type:LOGIN_SUCCESS,
    payload
});

export const loginFailure = ()=>({
    type:LOGIN_FAILURE,
})

export const login = ({username, password})=>(dispatch)=>{
    dispatch(loginLoading())
        fetch(`https://the-final-countdown-b.herokuapp.com/login`,{
          method:"post",
          body:JSON.stringify({
              "email":username,
              "password":password
            }),
          headers:{
              "Content-Type":"application/json"
          }
        }).then(res=>res.json()).then((res)=>dispatch(loginSuccess({token:res.token})))
        .catch(error=>dispatch(loginFailure()))
}