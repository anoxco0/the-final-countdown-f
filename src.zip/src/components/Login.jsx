import { useState } from "react"
import { useDispatch, useSelector } from "react-redux";
import { Navigate } from "react-router-dom"
import { login } from "../redux/login/action";


export const Login = ()=>{
    const dispatch = useDispatch();
    const [form, setForm] = useState({
       username:"",
       password:""
    })
    const {isAuthenticated} = useSelector(state=>state.login)
    const inputHandle = (e)=>{
         const {value, id} = e.target;
         setForm({...form, [id]:value});
    }

    const handleSubmit = ()=>{
        dispatch(login({username:form.username, password:form.password}))
    }

    if(isAuthenticated) return <Navigate to={'/'}/>
    return (
        <div className="login">
            <h1>Login</h1>
            <input onChange={(e)=>{inputHandle(e)}} type="text" name="" id="username" placeholder="Username"/>
            <input onChange={(e)=>{inputHandle(e)}} type="text" name="" id="password" placeholder="Password"/>
            <button onClick={()=>{handleSubmit()}}>Login</button>
        </div>
    )
}